/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectyo;

/**
 *
 * @author emene
 */
public class Cola {
    private NodoCola frente;
    private NodoCola ultimo;

    public NodoCola getFrente() {
        return frente;
    }

    public void setFrente(NodoCola frente) {
        this.frente = frente;
    }

    public NodoCola getUltimo() {
        return ultimo;
    }

    public void setUltimo(NodoCola ultimo) {
        this.ultimo = ultimo;
    }
    
    public void hacerFila(NodoCola elemento)
    {
        if(frente == null) // La fila está vacía
        {
            frente = elemento;
            ultimo = elemento;
        }
        else
        {
            //12        ->          13
            ultimo.setAtras(elemento);
            ultimo = elemento;
            
        }
    }
    
    public NodoCola atender()
    {
        NodoCola actual = frente;
        
        if(frente != null)
        {
            frente = frente.getAtras();
            actual.setAtras(null);
        }
        
        return actual;
    }
    
    public String imprimirCola()
    {
        String respuesta = ""; // En esta respuesta vamos a ir concatenando los nodos, para poder imprimirlos juntos
        NodoCola actual = frente;
        int i = 1;
        while(actual != null)
        {
            //Podemos hacer el recorrido
            respuesta += i + "-"+ actual.getPersona() + " - ";
            actual = actual.getAtras();
            i++;
        }
        
        return respuesta;
    }
}
