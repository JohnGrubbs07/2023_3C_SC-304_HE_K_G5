package proyectyo;

import org.ini4j.Ini;

public class ListaCircularDoble {

    //variable para contar el maximo de filas
    int conteoFilas = 0;
    private NodoCircularDoble cabeza;
    private NodoCircularDoble ultimo;

    public NodoCircularDoble getCabeza() {
        return cabeza;
    }

    public void setCabeza(NodoCircularDoble cabeza) {
        this.cabeza = cabeza;
    }

    public NodoCircularDoble getUltimo() {
        return ultimo;
    }

    public void setUltimo(NodoCircularDoble ultimo) {
        this.ultimo = ultimo;
    }
    
    public boolean estaVacia() {
        if (cabeza == null) {
            return false;
        }
        return true;
        
       }    //FIN DEL METODO VACIA

    public void inserta(int p, Pila b) {
        //Paso 1, de la presentación
        if (cabeza == null) {
            cabeza = new NodoCircularDoble(p, b);
            ultimo = cabeza;
            cabeza.setAnterior(ultimo);
            cabeza.setSiguiente(ultimo);
            ultimo.setSiguiente(cabeza);
            ultimo.setAnterior(cabeza);
            conteoFilas += 1;

        } else {

            //Paso 2, de la presentación
            if (cabeza.getId() > p) {
                //se agrego este if en todas las situaciones para validar que al insertar no se este excediendo la cantidad de filas
                
                    NodoCircularDoble aux = new NodoCircularDoble(p, b);
                    aux.setSiguiente(cabeza);
                    cabeza.setAnterior(aux);
                    cabeza = aux;
                    cabeza.setAnterior(ultimo);
                    ultimo.setSiguiente(cabeza);
                    conteoFilas += 1;
                
            } else {
                //Paso 3, de la presentación
                if (p > ultimo.getId()) {
                    
                        NodoCircularDoble aux = new NodoCircularDoble(p, b);
                        aux.setAnterior(ultimo);
                        ultimo.setSiguiente(aux);
                        ultimo = aux;
                        ultimo.setSiguiente(cabeza);
                        cabeza.setAnterior(ultimo);
                        conteoFilas += 1;
                    
                } else {
                    //Paso 4, de la presentación
                    
                        NodoCircularDoble aux = cabeza.getSiguiente();
                        while (aux.getId() < p) {
                            aux = aux.getSiguiente();
                        }

                        NodoCircularDoble temp = new NodoCircularDoble(p, b);
                        temp.setAnterior(aux.getAnterior());
                        temp.setSiguiente(aux); //Acá aux.getAnterior está apuntando (en su siguiente) a aux
                        aux.setAnterior(temp);
                        temp.getAnterior().setSiguiente(temp);
                        conteoFilas += 1;
                    
                }
            }
        }
    }

    @Override
    public String toString() {
        String respuesta = "Lista doble circular: \n";

        if (cabeza != null) {
            NodoCircularDoble aux = cabeza;

            respuesta += aux.toString() + "\n";

            aux = aux.getSiguiente();

            while (aux != cabeza) {
                respuesta += aux.toString() + "\n";
                aux = aux.getSiguiente();
            }
        } else {
            respuesta += "Vacía";
        }

        return respuesta;
    }
}
