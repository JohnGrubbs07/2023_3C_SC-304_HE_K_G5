package proyectyo;

public enum Vertices {
    Alajuela,
    Limon,
    Cartago,
    Heredia,
    SanJose,
    Puntarenas,
    Guanacaste
    

} //FIN DE LA CLASE
