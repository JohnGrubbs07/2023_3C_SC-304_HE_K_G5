package proyectyo;

public class NodoGrafo {

    private final int distancia;
  

    public NodoGrafo(int distancia) {
        
        this.distancia = distancia;
       
    } //FIN DEL CONSTRUCTOR

    public int getDistancia() {
        return distancia;
    } //FIN DEL GET DISTANCIA


    @Override
    public String toString() {
        return Integer.toString(distancia);
    } //FIN DEL OVERRIDE

} //FIN DE LA CLASE
