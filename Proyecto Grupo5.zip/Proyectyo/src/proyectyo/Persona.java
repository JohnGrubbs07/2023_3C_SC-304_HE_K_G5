package proyectyo;

public class Persona {
    private String nombre;
    private String edad;
    private String estacionOrigen;
    private String estacionDestino;
    private boolean discapacidad;
    private String estado;
    private int distancia;
    
    
    public Persona()
    {
    }

    public Persona(String nombre, String edad,String estacionOrigen,String estacionDestino,Boolean discapacidad,String estado,int distancia) {
        this.nombre = nombre;
        this.edad=edad;
        this.estacionOrigen=estacionOrigen;
        this.estacionDestino=estacionDestino;
        this.discapacidad=discapacidad;
        this.estado=estado;
        this.distancia=distancia;
    }

    public boolean isDiscapacidad() {
        return discapacidad;
    }

    public void setDiscapacidad(boolean discapacidad) {
        this.discapacidad = discapacidad;
    }

    public int getDistacia() {
        return distancia;
    }

    public void setDistacia(int distancia) {
        this.distancia = distancia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getEstacionOrigen() {
        return estacionOrigen;
    }

    public void setEstacionOrigen(String estacionOrigen) {
        this.estacionOrigen = estacionOrigen;
    }

    public String getEstacionDestino() {
        return estacionDestino;
    }

    public void setEstacionDestino(String estacionDestino) {
        this.estacionDestino = estacionDestino;
    }

    public Boolean getDiscapacidad() {
        return discapacidad;
    }

    public void setDiscapacidad(Boolean discapacidad) {
        this.discapacidad = discapacidad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }


    @Override
    public String toString() {
        return this.nombre+" "+this.edad+" "+this.estacionOrigen+" "+this.estacionDestino+" "+this.discapacidad+" "+this.estado;
    }
}
