package proyectyo;

public class NodoPila {
 
    private Persona elemento;
    private NodoPila siguiente;

    public NodoPila() 
    {
        this.siguiente = null;
    }
    
    public NodoPila getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoPila siguiente) {
        this.siguiente = siguiente;
    }

    public Persona getElemento() {
        return elemento;
    }

    public void setElemento(Persona elemento) {
        this.elemento = elemento;
    }
} //FIN DE LA CLASE

