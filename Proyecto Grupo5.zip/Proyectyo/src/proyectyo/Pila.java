package proyectyo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import org.ini4j.Ini;

public class Pila {
    private boolean disca;
    int conteoNorm = 0;
    int conteoDisca = 0;
    private NodoPila cima;

    public NodoPila getCima() {
        return cima;
        
    }

    public Pila(boolean disca) {
        this.cima = null;
        this.disca=disca;
    }

    public boolean isDisca() {
        return disca;
    }

    public void setDisca(boolean disca) {
        this.disca = disca;
    }
    
    public boolean esVacia() {
        if (cima == null) {
            return true;
        } else {
            return false;
        }
    }
    
    
    
    public void conteoPila(){
    // Restablecer conteos a cero antes de recalcular
    conteoNorm = 0;
    conteoDisca = 0;

    NodoPila actual = cima;
    while (actual != null) {
        if (actual.getElemento().getDiscapacidad()==true) {
            conteoDisca++;
        } else {
            conteoNorm++;
        }
        actual = actual.getSiguiente();
    }
    
}
    
    public void apilar(Persona p, int cantidadNorm, int cantidadDisca, boolean discapacidad) {
        conteoPila();
        
        NodoPila nuevo = new NodoPila();

        nuevo.setElemento(p);

        if (esVacia()) {
            if (discapacidad == true) {
                cima = nuevo;
              conteoDisca += 1;
            }//fin if
            if (discapacidad == false) {
                cima = nuevo;
                conteoNorm += 1;
            }//fin if

        } else {
            if (conteoNorm < cantidadNorm && discapacidad == false) {
                nuevo.setSiguiente(cima);
                cima = nuevo;
                
            }
            if (conteoDisca < cantidadDisca && discapacidad == true) {
                nuevo.setSiguiente(cima);
                cima = nuevo;
              
            }

        }
    }

    public void desapilar() {
        if (!esVacia()) {
            
                cima = cima.getSiguiente();
               

        } else {
            JOptionPane.showMessageDialog(null, "No se pueden extraer elementos de una pila vacía");
        }
    }

    public String imprimirPila() {
        String respuesta = "";
        if (!esVacia()) {

            NodoPila temp = cima;
            while (temp != null) {
                respuesta += temp.getElemento().toString() + "\n";
                temp = temp.getSiguiente();
            }
        } else {
            respuesta = "La pila está vacía";
        }

        return respuesta;
    }

} //FIN DE LA CLASE
