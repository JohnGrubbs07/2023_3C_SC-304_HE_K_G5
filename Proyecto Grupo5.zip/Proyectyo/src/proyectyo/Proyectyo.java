package proyectyo;

import java.io.IOException;

public class Proyectyo {

    public static void main(String[] args) throws IOException {
        Menu2 m = new Menu2();
        m.iniciarHilo();
        m.setVisible(true);

    }
} //FIN DE LA CLASE
