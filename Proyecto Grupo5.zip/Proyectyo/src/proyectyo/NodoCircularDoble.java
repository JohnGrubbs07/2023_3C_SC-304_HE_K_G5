
package proyectyo;


public class NodoCircularDoble {
     private Pila fila;
     private int id;
    private NodoCircularDoble anterior;
    private NodoCircularDoble siguiente;

    public NodoCircularDoble(int id, Pila fila) {
        this.id = id;
        this.fila=fila;
    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   
    public Pila getFila() {
        return fila;
    }

    public void setFila(Pila fila) {
        this.fila = fila;
    }
    

    public NodoCircularDoble getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoCircularDoble anterior) {
        this.anterior = anterior;
    }

    public NodoCircularDoble getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircularDoble siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return String.valueOf(id);
    }
}
