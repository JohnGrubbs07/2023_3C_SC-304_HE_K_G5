package proyectyo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import org.ini4j.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import static proyectyo.Vertices.Alajuela;

public class Vagon extends Thread {

    Grafo grafo = new Grafo(7);
    Ini lectura = new Ini();
    public ListaCircularDoble vagon = new ListaCircularDoble();
    
    Pila baseNorm = new Pila(false);
    Pila baseDis = new Pila(true);
    String nombreEmpresa;
    int tiempo;
    int filasDisca;
    int filasNorm;
    int precioKm;
    int asientosNorm;
    int asientosDisca;
    Cola normAla = new Cola();
    Cola discaAla = new Cola();
    Cola normLim = new Cola();
    Cola discaLim = new Cola();
    Cola normCar = new Cola();
    Cola discaCar = new Cola();
    Cola normHere = new Cola();
    Cola discaHere = new Cola();
    Cola normSan = new Cola();
    Cola discaSan = new Cola();
    Cola normPun = new Cola();
    Cola discaPun = new Cola();
    Cola normGua = new Cola();
    Cola discaGua = new Cola();
    Pila auxPila = new Pila(false);
    NodoPila auxNodoPila = new NodoPila();
    NodoCircularDoble auxCircu = vagon.getCabeza();
    Visualizar n = new Visualizar();
    String respuestaTotVerInfo = "";

    public void inicializarDatos() throws FileNotFoundException, IOException {
 //este metodo va a inicializar y crear las diferentes estructuras necesarias
        int conteoFilas = 0;
        //en esta parte de aca el sistema lee del archivo ini las variables base
        lectura.load(new FileReader("src/proyectyo/ini.ini"));
        nombreEmpresa = lectura.get("scene", "nombreEmpresa");
        precioKm = Integer.parseInt(lectura.get("scene", "costo"));
        filasDisca = Integer.parseInt(lectura.get("scene", "filasDisca"));
        filasNorm = Integer.parseInt(lectura.get("scene", "filasNorm"));
        asientosNorm = Integer.parseInt(lectura.get("scene", "asientosNorm"));
        asientosDisca = Integer.parseInt(lectura.get("scene", "asientosDisca"));
        tiempo = Integer.parseInt(lectura.get("scene", "tiempo"));

        // Agregar estaciones y colocandole sus respectivas estaciones
        grafo.setArista(Vertices.Alajuela.ordinal(), Vertices.Limon.ordinal(), 10);
        grafo.setArista(Vertices.Limon.ordinal(), Vertices.Cartago.ordinal(), 50);
        grafo.setArista(Vertices.Cartago.ordinal(), Vertices.Heredia.ordinal(), 30);
        grafo.setArista(Vertices.Heredia.ordinal(), Vertices.SanJose.ordinal(), 25);
        grafo.setArista(Vertices.SanJose.ordinal(), Vertices.Puntarenas.ordinal(), 40);
        grafo.setArista(Vertices.Puntarenas.ordinal(), Vertices.Guanacaste.ordinal(), 100);
        grafo.setArista(Vertices.Guanacaste.ordinal(), Vertices.Alajuela.ordinal(), 40);

        //con dos for se agregan la cantidad de filas de normales y discapacitados, tambien se le asigna una pila
        //con true si es de discapacitados o false si no
        for (int i = 0; i < filasNorm; i++) {
            vagon.inserta(conteoFilas, baseNorm);
            conteoFilas += 1;

        }//fin for
        for (int i = 0; i < filasDisca; i++) {
            vagon.inserta(conteoFilas, baseDis);
            conteoFilas += 1;

        }//fin for
        //se inicia el nombre de la empresa en el frame
        n.jTextPane1.setText(nombreEmpresa);
    }//fin inicializar

     public static void agregar(String respuesta)
    {
        try
        {
            //Aquí creamos el archivo y la entrada de datos
            DataOutputStream archivo = new DataOutputStream(new FileOutputStream("reportes.txt",true));
            //Aquí solicitamos los datos al usuario
          
                //Si los datos están correctos escribimos en el archivo
                archivo.writeUTF("\n"+respuesta);


                //Debemos cerrar el archivo una vez que dejemos de utilizarlo
                archivo.close();
                
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error al agregar los datos: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
     
    //metodo para agregar persona a cola
    public void hacerFila(String nombre, String edad, boolean discapacidad, int estacionOrigenConsulta, int estacionDestinoConsulta) {

        int origen = 0;
        int destino = 0;
        String estacionOrigen = "";
        String estacionDestino = "";
        //se piden una variables de entrada, dependiendo de la estacionOrigenConsulta se le definira la estacion
        switch (estacionOrigenConsulta) {
            case 1:
                estacionOrigen = "Alajuela";
                origen = 0;
                break;
            case 2:
                estacionOrigen = "Limon";
                origen = 1;
                break;
            case 3:
                estacionOrigen = "Cartago";
                origen = 2;
                break;
            case 4:
                estacionOrigen = "Heredia";
                origen = 3;
                break;
            case 5:
                estacionOrigen = "SanJose";
                origen = 4;
                break;
            case 6:
                estacionOrigen = "Puntarenas";
                origen = 5;
                break;
            case 7:
                estacionOrigen = "Guanacaste";
                origen = 6;
                break;
            default:
                JOptionPane.showMessageDialog(null, "Coloque una opcion valida");
        }
//dependiendo de la estacionDestinoConsulta se le define el destino
        switch (estacionDestinoConsulta) {
            case 1:
                estacionDestino = "Alajuela";
                destino = 0;
                break;
            case 2:
                estacionDestino = "Limon";
                destino = 1;
                break;
            case 3:
                estacionDestino = "Cartago";
                destino = 2;
                break;
            case 4:
                estacionDestino = "Heredia";
                destino = 3;
                break;
            case 5:
                estacionDestino = "SanJose";
                destino = 4;
                break;
            case 6:
                estacionDestino = "Puntarenas";
                destino = 5;
                break;
            case 7:
                estacionDestino = "Guanacaste";
                destino = 6;
                break;
            default:
                JOptionPane.showMessageDialog(null, "Coloque una opcion valida");
                hacerFila(nombre, edad, discapacidad, estacionOrigenConsulta, estacionDestinoConsulta);
        }
    //se le pone un estado de completado
        String estado = "EN_COLA";
   //con el metodo de dijkstra para sacar el valor del boleto
        int pago = (grafo.dijkstra(origen, destino)) * precioKm;
//creamos la persona con los datos anteriores
        Persona j = new Persona(nombre, edad, estacionOrigen, estacionDestino, discapacidad, estado, pago);
        NodoCola v = new NodoCola(j);
//dependiendo del origen se le define una cola especifica
        switch (estacionOrigen) {

            case "Alajuela":
                if (discapacidad == true) {
                    discaAla.hacerFila(v);
                }//fin if
                else {
                    normAla.hacerFila(v);
                }//fin else

                break;

            case "Limon":
                if (discapacidad == true) {
                    discaLim.hacerFila(v);
                }//fin if
                else {
                    normLim.hacerFila(v);
                }//fin else

                break;
            case "Cartago":
                if (discapacidad == true) {
                    discaCar.hacerFila(v);
                }//fin if
                else {
                    normCar.hacerFila(v);
                }//fin else

                break;
            case "Heredia":
                if (discapacidad == true) {
                    discaHere.hacerFila(v);
                }//fin if
                else {
                    normHere.hacerFila(v);
                }//fin else

                break;
            case "SanJose":
                if (discapacidad == true) {
                    discaSan.hacerFila(v);
                }//fin if
                else {
                    normSan.hacerFila(v);
                }//fin else

                break;
            case "Puntarenas":
                if (discapacidad == true) {
                    discaPun.hacerFila(v);
                }//fin if
                else {
                    normPun.hacerFila(v);
                }//fin else

                break;
            case "Guanacaste":
                if (discapacidad == true) {
                    discaGua.hacerFila(v);
                }//fin if
                else {
                    normGua.hacerFila(v);
                }//fin else

                break;

            default:
                JOptionPane.showMessageDialog(null, "Coloque una estacion valida");
                hacerFila(nombre, edad, discapacidad, estacionOrigenConsulta, estacionDestinoConsulta);
                break;
        }
    }//fin hacer fila
//este metodo va a ayudarme a mostrar el tren
    public void verTren() {
        int i = 0;
        //defino el auxcircu con cabeza de vagon
        auxCircu = vagon.getCabeza();
        String respuestaTot = "";
        i++;
        //se guarda la impresion la pila
        respuestaTot +="Fila:"+i+ auxCircu.getFila().imprimirPila();
        n.verTren.setText(respuestaTot);
        auxCircu = auxCircu.getSiguiente();
        //recorremos la lista
        while (auxCircu != vagon.getCabeza()) {
            //guardamos la impresion de la pila
            respuestaTot +="Fila:"+i+auxCircu.getFila().imprimirPila();
            n.verTren.setText(respuestaTot);
            auxCircu = auxCircu.getSiguiente();
        }
    }
//con este metodo vamos a bajar a los pasajeros
    public void bajarPasajeros(String estacion) {
       
        auxCircu = vagon.getCabeza();
        respuestaTotVerInfo = "";

        // Comprobar si hay vagones para procesar
        if (auxCircu == null) {
            System.out.println("No hay vagones para procesar.");
            return;
        }

        // Procesar todas las filas del vagon
        for (int i = 0; i < filasNorm + filasDisca; i++) {
            Pila filaActual = auxCircu.getFila();
            Pila auxPila = new Pila(false); //se crea pila aux para guardar los datos que se desapilen

            // Desapilar todos los pasajeros para sacar a la persona que se baja ahi
            while (!filaActual.esVacia()) {//se revisa si la pila es vacia
                //se crea una persona temp 
                Persona persona = filaActual.getCima().getElemento();
                filaActual.desapilar(); // Desapilar siempre, independientemente de si el pasajero se baja o no
                if (persona.getEstacionDestino().equals(estacion)) {//si la persona tiene como estacion destino esta lo baja
                    persona.setEstado("COMPLETADO");
                    respuestaTotVerInfo += "\nSe bajo: " + persona.getNombre() + " Que viene de: " + persona.getEstacionOrigen() + " Pago: " + persona.getDistacia();
                    n.verInfo.setText(respuestaTotVerInfo);
                    agregar(respuestaTotVerInfo);
                } else {
                    //si no lo apila en la pila temp
                    auxPila.apilar(persona, asientosNorm, asientosDisca, persona.getDiscapacidad()); // Guardar temporalmente a los pasajeros que no se bajan
                }
            }

            // Reapilar los pasajeros que no bajan en esta estación de nuevo en la fila original
            while (!auxPila.esVacia()) {
                Persona persona = auxPila.getCima().getElemento();
                filaActual.apilar(persona, asientosNorm, asientosDisca, persona.getDiscapacidad());
                auxPila.desapilar();
            }

            // Avanzar a la siguiente fila en el vagón
            auxCircu = auxCircu.getSiguiente();
        }

        System.out.println(respuestaTotVerInfo);
    }
//este monta los pasajeros de la cola normal y recibe la cola normal
    public void montarPasajerosNorm(Cola norm) {
        
    respuestaTotVerInfo="";
    //se define el auxCircu con cabeza de vagon.
     auxCircu = vagon.getCabeza();
     //se crea un bucle infinito mientras para recorrerlo
       while(auxCircu!=null){
           //este if se cualmple dependiendo del atributo de discapacidad de la fila
        if (!auxCircu.getFila().isDisca()) {
            //se llama este metodo que cuenta cuantas personas tiene la pila
            auxCircu.getFila().conteoPila();
            //se hace un if llamando la variable de conteoNorm de la pila que dice cuantas personas hay en la pila y tambien que si el frente de la cola no es null
            if (auxCircu.getFila().conteoNorm<asientosNorm && norm.getFrente()!=null) {
                //si entra apila la persona de la cola, le cambia el estado y lo saca de la cola
                norm.getFrente().getPersona().setEstado("EN_CAMINO");
                auxCircu.getFila().apilar(norm.getFrente().getPersona(), asientosNorm, asientosDisca, false);
                System.out.println("Se subio al tren:"+norm.getFrente().getPersona().getNombre()+" Va hacia:"+norm.getFrente().getPersona().getEstacionDestino()+" Estado:"+norm.getFrente().getPersona().getEstado());
                respuestaTotVerInfo+="\nSe subio al tren:"+norm.getFrente().getPersona().getNombre()+" Va hacia:"+norm.getFrente().getPersona().getEstacionDestino()+" Estado:"+norm.getFrente().getPersona().getEstado();
                n.verInfo.setText(respuestaTotVerInfo);
                agregar(respuestaTotVerInfo);
                norm.atender();
                
            }
        }
        //con este salto a la siguiente fila
        auxCircu=auxCircu.getSiguiente();
        //si el aux es igual a la cabeza para
        if (auxCircu == vagon.getCabeza()) {
            break;
        }
        
       }
}

//este monta los pasajeros de la cola discapacitados y recibe la cola de discapacitados
    public void montarPasajerosDisca(Cola disca){
      respuestaTotVerInfo="";
      //se define el auxCircu con cabeza de vagon.
     auxCircu = vagon.getCabeza();
     //se crea un bucle infinito mientras para recorrerlo
       while(auxCircu!=null){
            //este if se cualmple dependiendo del atributo de discapacidad de la fila
        if (auxCircu.getFila().isDisca()) {
            //se llama este metodo que cuenta cuantas personas tiene la pila
            auxCircu.getFila().conteoPila();
            //se hace un if llamando la variable de conteoNorm de la pila que dice cuantas personas hay en la pila y tambien que si el frente de la cola no es null
            if (auxCircu.getFila().conteoDisca<asientosDisca && disca.getFrente()!=null) {
                //si entra apila la persona de la cola, le cambia el estado y lo saca de la cola
                disca.getFrente().getPersona().setEstado("EN_CAMINO");
                auxCircu.getFila().apilar(disca.getFrente().getPersona(), asientosNorm, asientosDisca, false);
                System.out.println("Se subio al tren:"+disca.getFrente().getPersona().getNombre()+" Va hacia:"+disca.getFrente().getPersona().getEstacionDestino()+" Estado:"+disca.getFrente().getPersona().getEstado());
                respuestaTotVerInfo+="\nSe subio al tren:"+disca.getFrente().getPersona().getNombre()+" Va hacia:"+disca.getFrente().getPersona().getEstacionDestino()+" Estado:"+disca.getFrente().getPersona().getEstado();
                n.verInfo.setText(respuestaTotVerInfo);
                agregar(respuestaTotVerInfo);
                disca.atender();
                
            }
        }
         //con este salto a la siguiente fila
        auxCircu=auxCircu.getSiguiente();
         //si el aux es igual a la cabeza para
        if (auxCircu == vagon.getCabeza()) {
            break;
        }
        
       }
    }
    //con este metodo se lalma al agregara fila y agrega de un archivo una cierta cantidad de personas
    public void agregarFilaCvs(String nombre, String edad, boolean discapacidad, int estacionOrigenConsulta, int estacionDestinoConsulta, int cantidadPers) {
        for (int i = 0; i < cantidadPers; i++) {
            hacerFila(nombre, edad, discapacidad, estacionOrigenConsulta, estacionDestinoConsulta);
        }

    }
//este metodo lee el archivo de agregar personas
    public void leerCsv() throws IOException {
        String lectura;
        BufferedReader br = null;
        try {

            br = new BufferedReader(new FileReader("src/proyectyo/agregar.csv"));

            while ((lectura = br.readLine()) != null) {

                String nombre = "";
                String edad = "";
                int origen = 0;
                int destino = 0;
                int estacionOrigenConsulta = 0;
                int estacionDestinoConsulta = 0;
                boolean discapacidad = false;
                int cantidadPers = 0;
                String datos[] = lectura.split(",");
                nombre = datos[0];

                edad = datos[1];

                estacionOrigenConsulta = Integer.parseInt(datos[2]);

                estacionDestinoConsulta = Integer.parseInt(datos[3]);

                discapacidad = Boolean.valueOf(datos[4]);

                cantidadPers = Integer.parseInt(datos[5]);

                

                agregarFilaCvs(nombre, edad, discapacidad, estacionOrigenConsulta, estacionDestinoConsulta, cantidadPers);

            } //fin montar
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Vagon.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                br.close();

            } catch (IOException ex) {
                Logger.getLogger(Vagon.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
//se inicia un hilo para simular todo lo del tren
    @Override
    public void run() {
        //estas variables me van a servir para ir guardando diferentes datos del metodos para luego imprimirlos
        String respuestaNormal = "";
        String respuestaDisca = "";
        String respuestaTot = "";

        int j;
        int l;
        int infinito = 3;
        int inicio = 0;
        if (inicio == 0) {

            n.setVisible(true);
        }
//se crea un bloque infinito para que nunca pare el hilo
        while (infinito != 0) {
//se crea un for para ir recorriendo las 7 estaciones 
            for (int i = 0; i < 7; i++) {
                verTren();
                switch (String.valueOf(Vertices.values()[i])) {
//por medio de llamar el enum de vertices obtenemos un string con el nombre de la estacion
                    case "Alajuela" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Alajuela.name() + "\n";
                        
                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normAla.getFrente();
                        NodoCola actualDiscapa = discaAla.getFrente();
                        //por medio de estos dos whiles recorre las colas para luego imprimirlas
                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "-");
                            actualNormal = actualNormal.getAtras();

                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                        //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Alajuela");
                        montarPasajerosNorm(normAla);
                        montarPasajerosDisca(discaAla);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        //ensena en el jframe la cola de la estacion
                        n.ver.setText(respuestaTot);

                    }

                    case "Limon" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Limon.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normLim.getFrente();
                        NodoCola actualDiscapa = discaLim.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Limon");
                        montarPasajerosNorm(normLim);
                        montarPasajerosDisca(discaLim);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);
                    }
                    case "Cartago" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Cartago.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normCar.getFrente();
                        NodoCola actualDiscapa = discaCar.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Cartago");
                        montarPasajerosNorm(normCar);
                        montarPasajerosDisca(discaCar);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);
                    }
                    case "Heredia" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Heredia.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normHere.getFrente();
                        NodoCola actualDiscapa = discaHere.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Heredia");
                        montarPasajerosNorm(normHere);
                        montarPasajerosDisca(discaHere);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);

                    }
                    case "SanJose" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.SanJose.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normSan.getFrente();
                        NodoCola actualDiscapa = discaSan.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("SanJose");
                        montarPasajerosNorm(normSan);
                        montarPasajerosDisca(discaSan);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);
                    }
                    case "Puntarenas" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Puntarenas.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normPun.getFrente();
                        NodoCola actualDiscapa = discaPun.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Puntarenas");
                        montarPasajerosNorm(normPun);
                        montarPasajerosDisca(discaPun);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);
                    }
                    case "Guanacaste" -> {
                        respuestaTot = "";
                        respuestaTot += "Esta en la estacion de:" + Vertices.Guanacaste.name() + "\n";

                        j = 1;
                        l = 1;
                        respuestaNormal = "";
                        respuestaDisca = "";
                        NodoCola actualNormal = normGua.getFrente();
                        NodoCola actualDiscapa = discaGua.getFrente();

                        while (actualNormal != null) {
                            //Podemos hacer el recorrido

                            respuestaNormal = (respuestaNormal) + (j + "-" + actualNormal.getPersona().getNombre() + " Estacion de destino:" + actualNormal.getPersona().getEstacionDestino() + "\n");
                            actualNormal = actualNormal.getAtras();
                            j++;
                        }//fin while
                        while (actualDiscapa != null) {
                            //Podemos hacer el recorrido
                            respuestaDisca += l + "-" + actualDiscapa.getPersona().getNombre() + " Estacion de destino:" + actualDiscapa.getPersona().getEstacionDestino() + "\n";
                            actualDiscapa = actualDiscapa.getAtras();
                            l++;
                        }//fin while
                         //llama al metodo de bajar pasajeros primero para bajar los que se bajan en esta estacion
                        //llama al metodo de montar pasajerosNorm que monta a los de la cola de normales
                        //llama al metodo de montarpasajerosDisca para montar los de la cola de discapacitados
                        bajarPasajeros("Guanacaste");
                        montarPasajerosNorm(normGua);
                        montarPasajerosDisca(discaGua);
                        respuestaTot += "La fila normal tiene a:\n" + respuestaNormal + "\n";
                        respuestaTot += "La fila de discapacitados tiene a:\n" + respuestaDisca + "\n";
                        System.out.println(respuestaTot);
                        n.ver.setText(respuestaTot);

                    }

                    default -> {
                    }
                }

                try {

                    Thread.sleep(tiempo * 1000);
                    ;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }//fin for
        }
    }

}//fin vagon
